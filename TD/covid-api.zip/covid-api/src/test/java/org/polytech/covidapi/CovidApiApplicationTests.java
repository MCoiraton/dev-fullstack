package org.polytech.covidapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CovidApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
